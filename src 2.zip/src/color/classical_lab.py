from __future__ import annotations
import numpy as np
import cv2
from skimage.color import rgb2lab, lab2rgb, deltaE_ciede2000

def _median_ab(img_bgr: np.ndarray, mask: np.ndarray) -> tuple[float, float]:
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    lab = rgb2lab(rgb)
    m = mask.astype(bool)
    a_med = float(np.median(lab[..., 1][m]))
    b_med = float(np.median(lab[..., 2][m]))
    return a_med, b_med

def _lab_to_lch(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    C = np.sqrt(a*a + b*b)
    h = np.arctan2(b, a)
    return C, h

def _lch_to_ab(C: np.ndarray, h: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = C * np.cos(h)
    b = C * np.sin(h)
    return a, b

class ClassicalLabCorrector:
    """
    Classical recolor in LCh:
    - Mapping params estimated on *core* masks (robust)
    - Apply mapping to the *full* on-model garment mask
    - Preserve L; adjust hue rotation & chroma scale; small ΔE feedback
    """
    def __init__(self, deltaE_target: float = 2.0) -> None:
        self.deltaE_target = deltaE_target

    def correct(self,
                on_model_bgr: np.ndarray,
                on_model_mask_core: np.ndarray,
                on_model_mask_full: np.ndarray,
                ref_bgr: np.ndarray,
                ref_mask_core: np.ndarray) -> np.ndarray:

        om_rgb = cv2.cvtColor(on_model_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        rf_rgb = cv2.cvtColor(ref_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        om_lab = rgb2lab(om_rgb)
        rf_lab = rgb2lab(rf_rgb)

        # Medians on *cores*
        a_ref, b_ref = _median_ab(ref_bgr, ref_mask_core)
        a_om,  b_om  = _median_ab(on_model_bgr, on_model_mask_core)

        # Robust stats in LCh
        C_ref, h_ref = _lab_to_lch(np.array(a_ref), np.array(b_ref))
        C_om,  h_om  = _lab_to_lch(np.array(a_om),  np.array(b_om))

        C_scale = float((C_ref + 1e-6) / (C_om + 1e-6))
        h_shift = float(h_ref - h_om)
        ab_offset = (0.0, 0.0)

        def apply_map(mask_apply: np.ndarray, ab_offset=(0.0, 0.0)) -> np.ndarray:
            out = om_lab.copy()
            a = out[..., 1]; b = out[..., 2]
            C, h = _lab_to_lch(a, b)
            mm = mask_apply.astype(bool)
            C2 = C.copy(); h2 = h.copy()
            C2[mm] = C[mm] * C_scale
            h2[mm] = h[mm] + h_shift
            a2, b2 = _lch_to_ab(C2, h2)
            a2[mm] = a2[mm] + ab_offset[0]
            b2[mm] = b2[mm] + ab_offset[1]
            out[..., 1] = a2; out[..., 2] = b2
            return out

        # First pass: APPLY TO FULL MASK
        out_lab = apply_map(on_model_mask_full, ab_offset)

        # Feedback against ref *median* within core
        def dE_med_against_ref(out_lab_arr) -> float:
            out_rgb = np.clip(lab2rgb(out_lab_arr), 0, 1)
            out_bgr = (out_rgb * 255.0).astype(np.uint8)
            from .utils_for_delta import deltaE_between_medians  # if you prefer, inline the metric
            # Inline to avoid import: quick median ΔE:
            from skimage.color import rgb2lab, deltaE_ciede2000
            om_lab_now = rgb2lab(out_rgb)
            m = on_model_mask_core.astype(bool)
            if m.sum() == 0:
                return float("nan")
            Lm = float(np.median(om_lab_now[...,0][m]))
            am = float(np.median(om_lab_now[...,1][m]))
            bm = float(np.median(om_lab_now[...,2][m]))
            # ref medians:
            rm = ref_mask_core.astype(bool)
            rf_Lm = float(np.median(rf_lab[...,0][rm]))
            rf_am = float(np.median(rf_lab[...,1][rm]))
            rf_bm = float(np.median(rf_lab[...,2][rm]))
            ref = np.array([[[rf_Lm, rf_am, rf_bm]]], dtype=np.float32)
            tst = np.array([[[Lm, am, bm]]], dtype=np.float32)
            return float(deltaE_ciede2000(ref, tst)[0,0])

        dE = dE_med_against_ref(out_lab)
        for _ in range(2):
            if not np.isfinite(dE) or dE <= self.deltaE_target:
                break
            scale = self.deltaE_target / max(dE, 1e-3)
            ab_offset = (ab_offset[0] * scale, ab_offset[1] * scale)
            out_lab = apply_map(on_model_mask_full, ab_offset)
            dE = dE_med_against_ref(out_lab)

        out_rgb = np.clip(lab2rgb(out_lab), 0, 1)
        return (out_rgb * 255.0).astype(np.uint8)
