# src/pipeline/orchestrator.py
from __future__ import annotations

from pathlib import Path
from typing import Iterable
import numpy as np
import cv2

from ..schemas.config import AppConfig
from ..utils.logging_utils import get_logger
from ..pipeline.io import Pair
from ..masking.base import Masker
from ..masking.stilllife_rembg_sam2 import StillLifeRembgMasker
from ..masking.onmodel_schp_sam2 import OnModelColorPriorMasker
from ..color.classical_lab import ClassicalLabCorrector
from ..metrics.color_metrics import (
    deltaE_between_medians,
    deltaE_q_to_ref_median,
)
from ..metrics.texture_metrics import ssim_L
from ..qc.rules import evaluate


def _feather_mask(bin_mask: np.ndarray, px: int) -> np.ndarray:
    """Return float32 alpha in [0,1] after Gaussian feathering of a binary 0/255 mask."""
    px = max(1, int(px))
    blurred = cv2.GaussianBlur(bin_mask, (0, 0), px)
    return (blurred.astype(np.float32) / 255.0)


def _alpha_blend(src: np.ndarray, dst: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Blend dst into src using scalar alpha (H×W, 0..1)."""
    out = src.astype(np.float32)
    a3 = np.dstack([alpha, alpha, alpha])
    out = out * (1.0 - a3) + dst.astype(np.float32) * a3
    return np.clip(out, 0, 255).astype(np.uint8)


def run_pairs(
    pairs: Iterable[Pair],
    masks_dir: Path,
    output_dir: Path,
    logs_dir: Path,
    cfg: AppConfig,
) -> None:
    """
    Process each (still-life, on-model) pair and write corrected-on-model-<ID>.jpg.
    Uses:
      - Still-life mask: rembg
      - On-model mask: color prior from still-life (configurable τ), person FG - skin
      - Color correction: classical LCh mapping (hue rotation + chroma scale + ΔE feedback)
      - Metrics: region-wise ΔE (no pixel alignment), SSIM(L), spill ΔE in ring outside mask
    """
    logger = get_logger("orchestrator", logs_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    masks_dir.mkdir(parents=True, exist_ok=True)

    # Instantiate modules
    on_masker = OnModelColorPriorMasker(cfg.masking.onmodel_color_prior)
    st_masker = StillLifeRembgMasker()
    corrector = ClassicalLabCorrector(deltaE_target=cfg.color.deltaE_target)

    for i, p in enumerate(pairs, 1):
        try:
            logger.info(f"🧩 [{i}] ID={p.id} | Loading images")
            om = cv2.imread(str(p.on_model), cv2.IMREAD_COLOR)
            st = cv2.imread(str(p.still_life), cv2.IMREAD_COLOR)
            if om is None or st is None:
                raise RuntimeError("Failed to read one or both images.")

            logger.info("🧥 Getting masks (on-model, still-life)…")
            # Still-life: rembg → largest comp; core for robust stats
            st_mask = st_masker.get_mask(st)
            st_core = Masker.erode(st_mask, cfg.masking.erosion_px)

            # On-model: color-prior (τ from config) using still-life stats
            om_mask = on_masker.get_mask_with_ref(om, st, st_core, logger=logger)
            om_core = Masker.erode(om_mask, cfg.masking.erosion_px)
            alpha = _feather_mask(om_mask, cfg.masking.feather_px)

            # Guard: tiny/empty mask → skip
            if int(om_core.sum() // 255) < cfg.masking.onmodel_color_prior.min_mask_pixels:
                logger.warning(f"⚠️ [{i}] ID={p.id} on-model garment mask too small; skipping.")
                cv2.imwrite(str(masks_dir / f"on-model-{p.id}.png"), om_mask)
                cv2.imwrite(str(masks_dir / f"still-life-{p.id}.png"), st_mask)
                continue

            logger.info("🎛️ Color correcting (classical LCh + ΔE feedback)…")
            # NOTE: corrector now takes both core (for stats) and full mask (for application)
            corrected_inside = corrector.correct(
                on_model_bgr=om,
                on_model_mask_core=om_core,
                on_model_mask_full=om_mask,
                ref_bgr=st,
                ref_mask_core=st_core,
            )

            # Alpha-blend corrected region back (no spill)
            corrected = _alpha_blend(om, corrected_inside, alpha)

            # --- Region-wise metrics (no pixel alignment) ---
            dE_med = deltaE_between_medians(st, st_core, corrected, om_core)
            dE_p95 = deltaE_q_to_ref_median(corrected, om_core, st, st_core, q=95.0)
            ssim_val = ssim_L(corrected, om, om_core)

            # Spill: ring outside mask vs original
            ring = cv2.dilate(om_mask, np.ones((5, 5), np.uint8), iterations=1)
            ring = cv2.subtract(ring, om_mask)
            if ring.sum() == 0:
                spill_med = 0.0
            else:
                # ΔE(corrected, original) in the ring
                from skimage.color import rgb2lab, deltaE_ciede2000
                def _lab(x):
                    rgb = cv2.cvtColor(x, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
                    return rgb2lab(rgb)
                dE = deltaE_ciede2000(_lab(corrected), _lab(om))
                vals = dE[ring.astype(bool)]
                spill_med = float(np.median(vals)) if vals.size else 0.0

            qc = evaluate(
                dE_med if np.isfinite(dE_med) else 999.0,
                dE_p95 if np.isfinite(dE_p95) else 999.0,
                ssim_val if np.isfinite(ssim_val) else 0.0,
                spill_med,
                cfg.qc.max_deltaE_median,
                cfg.qc.max_deltaE_p95,
                cfg.qc.min_ssim_L,
                cfg.qc.max_spill_deltaE,
            )

            logger.info(
                f"📊 QC | ΔE_med={dE_med:.2f} ΔE_p95={dE_p95:.2f} "
                f"SSIM_L={ssim_val:.3f} spill={spill_med:.2f} → "
                f"{'✅ PASS' if qc.passed else '❌ FAIL'}"
            )

            # Save outputs & masks
            cv2.imwrite(str(output_dir / f"corrected-on-model-{p.id}.jpg"), corrected)
            cv2.imwrite(str(masks_dir / f"on-model-{p.id}.png"), om_mask)
            cv2.imwrite(str(masks_dir / f"still-life-{p.id}.png"), st_mask)

        except Exception as e:
            logger.error(f"❌ [{i}] ID={p.id} failed: {e}")
