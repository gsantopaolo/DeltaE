from __future__ import annotations
import numpy as np, cv2
from .base import Masker
from rembg import remove
from ..schemas.config import OnModelColorPriorConfig

def _largest_component(binm: np.ndarray) -> np.ndarray:
    num, labels, stats, _ = cv2.connectedComponentsWithStats(binm, connectivity=8)
    if num <= 1: return binm
    largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
    return np.where(labels == largest, 255, 0).astype(np.uint8)

def _skin_mask_ycrcb(image_bgr: np.ndarray) -> np.ndarray:
    ycrcb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2YCrCb)
    skin = cv2.inRange(ycrcb, (0,120,70), (255,190,140))
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3,3))
    return cv2.morphologyEx(skin, cv2.MORPH_OPEN, k, iterations=1)

def _person_fg(image_bgr: np.ndarray) -> np.ndarray:
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    rgba = remove(rgb)
    alpha = rgba[...,3] if rgba.shape[-1] == 4 else np.full(rgb.shape[:2], 255, np.uint8)
    _, binm = cv2.threshold(alpha, 0, 255, cv2.THRESH_BINARY)
    return _largest_component(binm)

def _ab_median_and_mad(ref_bgr: np.ndarray, ref_mask: np.ndarray) -> tuple[float,float,float]:
    lab = cv2.cvtColor(ref_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    m = ref_mask.astype(bool)
    a = lab[...,1][m]; b = lab[...,2][m]
    if a.size == 0:
        return 0.0, 0.0, 25.0
    am = float(np.median(a)); bm = float(np.median(b))
    r = np.sqrt((a - am)**2 + (b - bm)**2)
    mad = float(np.median(np.abs(r - np.median(r)))) + 1e-6
    return am, bm, mad

class OnModelColorPriorMasker(Masker):
    def __init__(self, cfg: OnModelColorPriorConfig) -> None:
        self.cfg = cfg

    def get_mask_with_ref(self, image_bgr: np.ndarray,
                          ref_bgr: np.ndarray, ref_mask_core: np.ndarray,
                          logger=None) -> np.ndarray:
        fg = _person_fg(image_bgr)
        skin = _skin_mask_ycrcb(image_bgr)
        fg = cv2.bitwise_and(fg, cv2.bitwise_not(skin))

        a_ref, b_ref, mad = _ab_median_and_mad(ref_bgr, ref_mask_core)
        lab = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
        a = lab[...,1]; b = lab[...,2]
        dist = np.sqrt((a - a_ref)**2 + (b - b_ref)**2)

        tau = max(self.cfg.tau_base, self.cfg.tau_k * mad)
        color_like = (dist <= tau).astype(np.uint8) * 255

        cand = cv2.bitwise_and(fg, color_like)
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))
        cand = cv2.morphologyEx(cand, cv2.MORPH_OPEN,  k, iterations=1)
        cand = cv2.morphologyEx(cand, cv2.MORPH_CLOSE, k, iterations=2)
        if self.cfg.dilate_px > 0:
            kd = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (self.cfg.dilate_px*2+1,)*2)
            cand = cv2.dilate(cand, kd, iterations=1)

        mask = _largest_component(cand)

        # Fill holes so white logos sit inside the garment mask
        h, w = mask.shape
        ff = mask.copy()
        cv2.floodFill(ff, np.zeros((h+2, w+2), np.uint8), (0, 0), 128)
        holes = (ff == 0).astype(np.uint8) * 255
        mask = cv2.bitwise_or(mask, holes)

        if logger is not None:
            sz = int(mask.sum() // 255)
            logger.info(f"🎯 Color-prior τ={tau:.2f} (base={self.cfg.tau_base}, k*mad={self.cfg.tau_k*mad:.2f}) | mask_px={sz}")

        return mask

    def get_mask(self, image_bgr: np.ndarray) -> np.ndarray:
        fg = _person_fg(image_bgr)
        skin = _skin_mask_ycrcb(image_bgr)
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5))
        base = cv2.bitwise_and(fg, cv2.bitwise_not(skin))
        base = cv2.morphologyEx(base, cv2.MORPH_CLOSE, k, iterations=2)
        return _largest_component(base)
