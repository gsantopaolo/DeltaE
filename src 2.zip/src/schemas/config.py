from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal

class OnModelColorPriorConfig(BaseModel):
    tau_base: float = 12.0
    tau_k: float = 3.0
    dilate_px: int = 0
    min_mask_pixels: int = 1000

class PathsConfig(BaseModel):
    input_dir: str
    masks_dir: str
    output_dir: str
    logs_dir: str

class RunConfig(BaseModel):
    limit: int = 300
    num_workers: int = 2
    save_debug: bool = False

class MaskingConfig(BaseModel):
    erosion_px: int = 3
    feather_px: int = 2
    use_sam2_refine: bool = False
    onmodel_color_prior: OnModelColorPriorConfig = Field(default_factory=OnModelColorPriorConfig)

class ColorConfig(BaseModel):
    mode: Literal["classical", "lut", "diffusion"] = "classical"
    deltaE_target: float = 2.0

class QCConfig(BaseModel):
    max_deltaE_median: float = 3.0
    max_deltaE_p95: float = 8.0
    min_ssim_L: float = 0.90
    max_spill_deltaE: float = 0.5

class AppConfig(BaseModel):
    paths: PathsConfig
    run: RunConfig = Field(default_factory=RunConfig)
    masking: MaskingConfig = Field(default_factory=MaskingConfig)
    color: ColorConfig = Field(default_factory=ColorConfig)
    qc: QCConfig = Field(default_factory=QCConfig)
